<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: login-user.php');
}

$email=$_SESSION["email"];
$query=mysqli_query($con,"select * from usertable where email='$email'");
$row=mysqli_fetch_array($query);
$id=$row["id"];
if(isset($_REQUEST["submit"]))
{
    $fullname=$_REQUEST["fullname"];
    $enrollment=$_REQUEST["enrollment"];
    $branch=$_REQUEST["branch"];
    $year=$_REQUEST["year"];
    $emailid=$_REQUEST["emailid"];
    $gender=$_REQUEST["gender"];
    $address=$_REQUEST["address"];
    $postgrad=$_REQUEST["postgrad"];
    $uni=$_REQUEST["uni"];
    $pass=$_REQUEST["pass"];
    $bran=$_REQUEST["bran"];
    $employ=$_REQUEST["employ"];
    $company=$_REQUEST["company"];
    $work=$_REQUEST["work"];




mysqli_query($con,"insert into post(fullname,enrollment,branch,year,emailid,gender,address,postgrad,uni,pass,bran,employ,company,work,user_id)value('$fullname','$enrollment','$branch','$year','$emailid','$gender','$address','$postgrad','$uni','$pass','$bran','$employ','$company','$work','$id')");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $fetch_info['name'] ?> | Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
    nav{
        padding-left: 100px!important;
        padding-right: 100px!important;
        background: #6665ee;
        font-family: 'Poppins', sans-serif;
    } 
    nav a.navbar-brand{
        color: #fff;
        font-size: 30px!important;
        font-weight: 500;
    }
    button a{
        color: #6665ee;
        font-weight: 500;
    }
    button a:hover{
        text-decoration: none;
    }
    </style>
</head>
<body>
    <nav class="navbar" >
    <a class="navbar-brand" href="#"><img src="../images/vit2.png"></a> 
    <button type="button" class="btn btn-light"><a href="post.php">View Details</a></button>
    <h1>Welcome <?php echo $fetch_info['name'] ?></h1>
    <button type="button" class="btn btn-light"><a href="logout-user.php">Logout</a></button>
</nav>

<br>
<h1 align="center">Fill Alumni Details</h1>
<br>

<form method="post">

<table border="1" align="center">

<tr>
<td>Full Name</td>
<td><input type="text" name="fullname" placeholder="Enter Full Name" required></td>
</tr>

<tr>
<td>Enrollment No</td>
<td><input type="number" name="enrollment" placeholder="Enter Enrollment No" required></td>
</tr>

<tr>
<td>Branch</td>
<td><input type="text" name="branch" placeholder="Enter Branch" required></td>
</tr>

<tr>
<td>Year of Passsing</td>
<td><input type="number" name="year" placeholder="Enter Year of Passing" required></td>
</tr>

<tr>
<td>Email Id</td>
<td><input type="email" name="emailid"placeholder="Enter Email-Id" required></td>
</tr>


<td>Gender</td>
<td>
<input type="radio" name="gender" value="Male" required>Male
<input type="radio" name="gender" value="Female" required>Female
</td>
</tr>


<td>Address</td>
<td><textarea name="address" placeholder="Enter Home Address" required></textarea></td>
</tr>

<tr>
<td>Post Graduation</td>
<td><input type="text" name="postgrad" placeholder="If not done enter nil"></td>
</tr>

<tr>
<td>Post Graduation University</td>
<td><input type="text" name="uni" placeholder="If not done enter nil"></td>
</tr>

<tr>
<td>Post Graduation Year of Passing</td>
<td><input type="number" name="pass" placeholder="If not done enter 0"></td>
</tr>

<tr>
<td>Post Graduation Branch</td>
<td><input type="text" name="bran" placeholder="If not done enter nil"></td>
</tr>

<tr>
<td>Employment Status</td>
<td><input type="radio" name="employ" value="Employed" required>Employed
    <input type="radio" name="employ" value="Self-Employed" required>Self-Employed
    <input type="radio" name="employ" value="Unemployed" required>Unemployed</td>
</tr>


<tr>
<td>Company Name</td>
<td><input type="text" name="company" placeholder="If not employed enter nil"></td>
</tr>

<tr>
<td>Work Experience</td>
<td><input type="text" name="work"></td>
</tr>

<tr>
<td><input type="submit" name="submit"></td>
</tr>


</table>

</form>



</body>
</html>