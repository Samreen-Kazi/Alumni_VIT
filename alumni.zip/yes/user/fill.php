<?php
session_start();
$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"alumni");
?>

<?php
if(isset($_REQUEST["submit"]))
{
	  $uname=$_REQUEST["uname"];
	  $enroll=$_REQUEST["enroll"];
	  $branch=$_REQUEST["branch"];
	  $passing=$_REQUEST["passing"];
	  $email=$_REQUEST["email"];
	  $contact=$_REQUEST["contact"];
	  $dob=$_REQUEST["dob"];
	  $gender=$_REQUEST["gender"];
	  $address=$_REQUEST["address"];
	  $address2=$_REQUEST["address2"];
	  $city=$_REQUEST["city"];
	  $state=$_REQUEST["state"];
	  $zip=$_REQUEST["zip"];
	  $grad=$_REQUEST["grad"];
	  $college=$_REQUEST["college"];
	  $branch2=$_REQUEST["branch2"];
	  $pass=$_REQUEST["pass"];
	  $employ=$_REQUEST["employ"];
	  $company=$_REQUEST["company"];
	  $work=$_REQUEST["work"];


	  mysqli_query($con,"insert into file(uname,enroll,branch,passing,email,contact,dob,gender,address,address2,city,state,zip,grad,college,branch2,pass,employ,company,work,user_id)value('$uname','$enroll','$branch','$passing','$email','$contact','$dob','$gender','$address','$address2''$city','$state','$zip','$grad','$college','$branch2','$pass','$employ','$company','$work')");
}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Fill alumni</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
</head>
<body>

<form method="post">




	<h1><center> Alumni Details</center></h1>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="uname">Name</label>
      <input type="text" class="form-control" id="uname" name="uname" placeholder="Full Name" required>
    </div>
       <div class="form-group col-md-6">
      <label for="enroll">Enrollment Number</label>
      <input type="number" class="form-control" id="enroll" name="enroll" placeholder="Enrollment Number of college"pattern="[0-9]{10}"required>
    </div>

      <div class="form-group col-md-6">
      <label for="branch">Branch</label>
      <input type="text" class="form-control" id="branch" name="branch" placeholder="Branch Name eg. INFT,CMPN etc.." required>
    </div>


      <div class="form-group col-md-6">
      <label for="passing">Year of Passing</label>
      <input type="text" class="form-control" id="passing" name="passing" placeholder="Year of Passing eg 2012" required>
    </div>


    <div class="form-group col-md-6">
      <label for="email">Email</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
    </div>

     <div class="form-group col-md-6">
      <label for="contact">Contact Number</label>
      <input type="tel" class="form-control" id="contact" name="contact" placeholder="Contact Number 10 digits" pattern="[7-9]{1}[0-9]{9}" required>
    </div>
 <div class="form-group col-md-6">
      <label for="dob">Date of Birth</label>
      <p id="resultBday"></p>
  <input type="date" class="form-control" name="dob" id="dob"required>
    </div>
 <div class="form-group col-md-6">
      <label for="gender">Gender</label>
      <br>
      <input class="form-group" type="radio" name="gender" id="gender"required>Male
      <input class="form-group" type="radio" name="gender" id="gender"required>Female
    </div>
  </div>


  <div class="form-group">
    <label for="address">Address</label>
    <input type="text" class="form-control" id="address" name="address" placeholder="Building No..."required>
  </div>
  <div class="form-group">
    <label for="address2">Address 2</label>
    <input type="text" class="form-control" id="address2" name="address2" placeholder="Road...">
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="city">City</label>
      <input type="text" class="form-control" id="city" name="city"required>
    </div>
    <div class="form-group col-md-4">
      <label for="state">State</label>
      <input type="text" class="form-control" id="state" name="state"required>
    </div>
    <div class="form-group col-md-2">
      <label for="zip">Zip</label>
      <input type="text" class="form-control" id="zip" name="zip"required>
    </div>
  </div>


<div class="form-row">

 <div class="form-group col-md-6">
    <label for="grad">Post Graduation Field</label>
    <input type="text" class="form-control" id="grad" name="grad" placeholder="MBA,ME,MS etc"required>
  </div>

 <div class="form-group col-md-6">
      <label for="college">Post-Grad College Name</label>
      <input type="text" class="form-control" id="college" name="college"required>
    </div>

  <div class="form-group col-md-6">
      <label for="branch2">Branch</label>
      <input type="text" class="form-control" id="branch2" name="branch2"required>
    </div>

   <div class="form-group col-md-6">
      <label for="pass">Year of Passing</label>
      <input type="text" class="form-control" id="pass" name="pass"required>
    </div>
  

 <div class="form-group col-md-6">
    <label for="grad">Employement Status</label>
    <input type="radio" class="form-group" id="employ" name="employ"required>Employed
    <input type="radio" class="form-group" id="employ" name="employ"required>Self-Employed
    <input type="radio" class="form-group" id="employ" name="employ"required>Unemployed
  </div>

 <div class="form-group col-md-6">
   <label for="company">Company Name</label>
   <input type="text" class="form-control" id="company" name="company" placeholder="Current/Previous Employement"required>
   </div>

 <div class="form-group col-md-6">
   <label for="work">Work Experience</label>
   <input type="text" class="form-control" id="work" name="work" placeholder="2 years,5 years etc.."required>
   </div>
</div>
<button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
</body>
</html>





