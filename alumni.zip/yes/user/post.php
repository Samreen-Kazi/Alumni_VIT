<?php
session_start();
$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"alumni");
?>


<?php
$email=$_SESSION["email"];
$query1=mysqli_query($con,"select * from usertable where email='$email'");
$row1=mysqli_fetch_array($query1);
$id=$row1["id"];
$query=mysqli_query($con,"select * from post where user_id=$id");
$rowcount=mysqli_num_rows($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
    nav{
        padding-left: 100px!important;
        padding-right: 100px!important;
        background: #6665ee;
        font-family: 'Poppins', sans-serif;
    } 
    nav a.navbar-brand{
        color: #fff;
        font-size: 30px!important;
        font-weight: 500;
    }
    button a{
        color: #6665ee;
        font-weight: 500;
    }
    button a:hover{
        text-decoration: none;
    }
    </style>
</head>
<body>
    <nav class="navbar" >
    <a class="navbar-brand" href="#"><img src="../images/vit2.png"></a> 
    <button type="button" class="btn btn-light"><a href="home.php">Home</a></button>
    <h1>View Details</h1>
    <button type="button" class="btn btn-light"><a href="logout-user.php">Logout</a></button>
</nav>

<table border="1">
<tr>
<td>Full Name</td>
<td>Enrollment Number</td>
<td>Branch</td>
<td>Year of Passing</td>
<td>Email Id</td>
<td>Gender</td>
<td>Address</td>
<td>Post Graduation</td>
<td>Post Graduation University</td>
<td>Post Graduation Year of Passing</td>
<td>Post Graduation Branch</td>
<td>Employment Status</td>
<td>Company Name</td>
<td>Work Experience</td>
</tr>
<?php
for($i=1;$i<=$rowcount;$i++)
{
	  $row=mysqli_fetch_array($query);
	  
?>
<tr>
<td><?php echo $row["fullname"] ?></td>
<td><?php echo $row["enrollment"] ?></td>
<td><?php echo $row["branch"] ?></td>
<td><?php echo $row["year"] ?></td>
<td><?php echo $row["emailid"] ?></td>
<td><?php echo $row["gender"] ?></td>
<td><?php echo $row["address"] ?></td>
<td><?php echo $row["postgrad"] ?></td>
<td><?php echo $row["uni"] ?></td>
<td><?php echo $row["pass"] ?></td>
<td><?php echo $row["bran"] ?></td>
<td><?php echo $row["employ"] ?></td>
<td><?php echo $row["company"] ?></td>
<td><?php echo $row["work"] ?></td>
</tr>

<?php
}
?>
</table>
</body>
</html>
