<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Guide Alumni</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
	<div class="container-fluid">
		<a class="navbar-brand" href="#"><img src="images/vit.png"></a>
		<button class="navbar-toggler" type="button" data-toggle="collaspse" data-target="navbarResponsive">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collaspse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
					<a id="home_btn" class="nav-link" href="#slides">Home</a>
				</li>
				<li class="nav-item">
					<a id="about_btn" class="nav-link" href="#about">About</a>
				</li>
				<li class="nav-item">
					<a id="team_btn" class="nav-link" href="#team">Alumni</a>
				</li>
				<li class="nav-item">
					<a id="connect_btn" class="nav-link" href="contact/index.html">Contact</a>
				</li>
				<li class="nav-item">
					<a id="login_btn" class="nav-link" href="user/login-user.php">Login</a>
				</li>
				<li class="nav-item">
					<a id="registration_btn" class="nav-link" href="user/signup-user.php">Registration</a>
				</li>
			</ul>
		</div>
	</div>
</nav>


<!--- Image Slider -->
<div id="slides" class="carousel slide" data-ride="carousel">
	<ul class="carousel-indicators">
		<li data-target="#slides" data-slide-to="0" class="active"></li>
		<li data-target="#slides" data-slide-to="1"></li>
		<li data-target="#slides" data-slide-to="2"></li>
	</ul>
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="images/PIC1.jpeg">
			<div class="carousel-caption">
				<h1 class="display-2"></h1>
				<h3></h3>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<button type="button" class="btn btn-info btn-primary btn-lg"> Sign In</button>
				<button type="button" class="btn btn-primary btn-lg">Register Now!</button>
			</div>
		</div>
		<div class="carousel-item">
			<img src="images/PIC2.png">
			    <div class="carousel-caption">
				<h3></h3></div>
			</div>
		<div class="carousel-item">
			<img src="images/PIC3.jpg">
			<div class="carousel-caption">
			<h3><h3></div>
		</div>
		</div>
	</div>
</div>


<!--- Jumbotron -->
<div class="container-fluid">
	<div class="row jumbotron">
		<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
			<p class="lead"><b>Did You Know ?</b><br>
				Vidyalankar Institute of Technology has received accreditation with an A+ Grade by National Assessment and Accreditation Council (NAAC). 

			 </p>
		</div>
	</div>
</div>

<!---welcome section of about---->

<div class="container-fluid padding" id="about">
	<div class="row welcome text-center">
		<div class="col-12">
			<h1 class="display-4"> About Us.</h1>
		</div>
		<hr>
		<div class="col-12">
			<p class="lead">
			The institute is a part of Vidyalankar Group which was established almost six decades ago, and has been making surefooted strides in the domain of education ever since.<br>
			The Institute emphasizes on providing a digitally enabled learning environment which ensures that learning takes place effectively and is in tune with fulfilling the educational requirements of tech-savvy millennials. </p>
			
		</div>
	</div>
</div>

<!--About Section -->
<div class="row about-cols">

          <div class="col-md-4 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <img src="images/mission.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Mission</a></h2>
              <p>
                 Evolve a curriculum which emphasizes on strong fundamentals with the flexibility to choose advanced courses of interest and gain exposure to tools and techniques in contemporary subjects.<br>
                 Encourage a teaching-learning process in which highly competent faculty share a symbiotic association with institutes of repute.<br>
       
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.1s">
            <div class="about-col">
              <div class="img">
                <img src="images/plan.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-list-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Core Values Are</a></h2>
              <p>
                Honesty<br>
                Integrity<br>
                Excellence<br>
                Responsibility<br>
                Commitment<br>
                Salubrious Attitude<br>
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="images/vision.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Vision</a></h2>
              <p>
                To be a globally recognized institute where learners are nurtured in a scholarly environment to evolve into competent professionals and researchers to benefit society.
              </p>
            </div>
          </div>

        </div>

      </div>

<!--- Meet the Alumni -->
<div class="container-fluid padding" id="team">
	<div class="row welcome text-center">
		<div class="col-12">
			<h1 class="display-4"> Meet the Alumni</h1>
		</div>
		<hr>
		</div>
	</div>

<!--- Cards -->
<div class="container-fluid padding" >
	<div class="row padding">
      <div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="images/alumni1.png">
      		<div class="card-body">
      			<h4 class="card-title">Abhay Valsangkar</h4>
      			<p class="card-text">
      				<b>Graduating Batch, 2015 <br>
      				Founder - Alter Ego Learning</b><br>
      			Life at Vidyalankar has always been full of learning and fun. In 4 years, I developed an array of qualities that are imperative to be a successful engineer. The time I spent here had an astonishing influence on my personality. Excellent learning environment, good faculty members, high class facilities, open culture and a supportive staff makes Vidyalankar an ideal place to be at  </p>
      		</div>
      	</div>
      </div>	

<div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="images/alumni2.png">
      		<div class="card-body">
      			<h4 class="card-title">Gaurav Kamboj</h4>
      			<p class="card-text"><b>Graduating Batch, 2013<br>
      			Now employed with Hotstar as Cloud Architect</b><br>
      			What I am today is because of the knowledge and values that Vidyalankar has taught me. VIT provides its students with an altogether rich experience. The infrastructure, facilities, college festivals, technical events are simply mesmerising. My journey at VIT was an exciting one and it has helped me in transforming my personality and attitude towards my career.</p>
      		</div>
      	</div>
      </div>	

<div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="images/alumni3.png">
      		<div class="card-body">
      			<h4 class="card-title">Jaideep Patel</h4>
      			<p class="card-text"><b>Graduating Batch, 2003 <br>
      				Founder - Brontoo Technology Solutions Pvt. Ltd.<br></b>
      			VIT has given me a very strong foundation and we need to leave a strong legacy when we walk out of the college. VIT is the best engineering college in Mumbai as it has a strong vision in the holistic development of its students. VIT gives its students an International exposure when it comes to educational visits, internships etc. I am an extremely proud alumni with a very strong connection with the institute</p>
      		</div>
      	</div>
      </div>	

	</div>
	<hr class="my-4">
</div>

<!--- Two Column Section -->

<!--- Connect -->

<div class="container-fluid padding" id="connect">
	<div class="row text-center padding">
		<div class="col-12">
			<h2 class="con1"> Connect</h2>
		</div>
		<div class="col-12 social padding">
			<a href="#"><i class="fab fa-facebook"></i></a>
			<a href="#"><i class="fab fa-twitter"></i></a>
			<a href="#"><i class="fab fa-google-plus-g"></i></a>
			<a href="#"><i class="fab fa-instagram"></i></a>
			<a href="#"><i class="fab fa-youtube"></i></a>	
		</div>
</div>
</div>



<!--- Footer -->
<footer>
	<div class="container-fluid padding">
		<div class="row text-center">
			<div class="col-md-4">
				<img src="images/vit2.png">
				<hr class="light">
				<p>Vidyalankar Institute of Technology is an Engineering & Management Institute approved by AICTE, New Delhi and Government of Maharashtra.
				The Institute is affiliated to University of Mumbai.</p>
		</div>
		<div class="col-md-4">
			<hr class="light">
			<h5> Our Hours</h5>
			<hr class="light">
			<p> Monday: 9am - 5pm</p>
			<p> Saturday: 10am - 4pm</p>
			<p> Sunday: closed</p>
		</div>
		<div class="col-md-4">
			<hr class="light">
			<h5> Contact Us</h5>
			<hr class="light">
			<p>Vidyalankar Institute of Technology, Vidyalankar College Marg, Wadala(E), Mumbai-400 037</p>
			<p>Phone: +91 22 2416 11 26
			</p>
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15087.864991286944!2d72.870471!3d19.0212089!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8d44ea4f85af3ceb!2sVidyalankar%20School%20of%20Information%20Technology!5e0!3m2!1sen!2sin!4v1626687485294!5m2!1sen!2sin" width="400" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>s
  <script src="script.js"></script>
		</div>
		<div class="col-12">
			<hr class="light-100">
			<h5>&copy;vitguidealumni.com</h5>
		</div>
	</div>
</div>
</footer>
</body>
</html>


















